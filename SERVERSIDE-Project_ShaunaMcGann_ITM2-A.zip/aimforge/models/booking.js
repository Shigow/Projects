const mongoose = require('mongoose');
const Schema =  mongoose.Schema
const Schemaful = new Schema ({
    name:{ type: String, required: true },
    id: { type: String, required: true },
    dateTime: { type: Date, required: true },
    cardNumber: { type: String, required: true },
    expiryDate: { type: String, required: true },
    securityCode: { type: String, required: true },
    createdAt: { type: Date, default: Date.now }
});

const booking = mongoose.model('Booking', Schemaful)
module.exports = booking;